# Transport Security Interface
An abstraction library over crypto and auth modules (typically OpenSSL)
